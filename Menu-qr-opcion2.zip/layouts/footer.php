  

    <div class="container-fluid bg-dark text-center py-2 footer">
        <p>Diseñado por Mitso Tech</p>
    </div>